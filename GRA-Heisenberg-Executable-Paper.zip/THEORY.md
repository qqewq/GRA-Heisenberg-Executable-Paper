Theory and analogies (EN/RU).
