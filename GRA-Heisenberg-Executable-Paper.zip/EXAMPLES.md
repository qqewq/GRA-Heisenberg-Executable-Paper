Examples (EN/RU).
