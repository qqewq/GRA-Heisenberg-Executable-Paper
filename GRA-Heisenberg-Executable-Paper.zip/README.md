# GRA–Heisenberg Reasoning Architecture

Executable research paper.
