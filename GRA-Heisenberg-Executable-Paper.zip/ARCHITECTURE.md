Architecture description (EN/RU).
