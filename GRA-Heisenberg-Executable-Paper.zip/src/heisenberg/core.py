class BeliefState:
    pass
